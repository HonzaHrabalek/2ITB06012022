﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        bool left;
        bool right;
        bool up;
        bool down;
        int delka = 10;

        public Form1()
        {
            InitializeComponent();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {

            if (e.KeyCode == Keys.Up && panel1.Location.Y < this.Height)
            { 
                bool up = true;
                panel1.Location = new Point(panel1.Location.X, panel1.Location.Y - delka);
            }
            if (e.KeyCode == Keys.Down && panel1.Location.Y < this.Height)
            {
                bool down = true;
                panel1.Location = new Point(panel1.Location.X, panel1.Location.Y + delka);
            }
            if (e.KeyCode == Keys.Left && Form1.ActiveForm.Right - panel1.Right >= 0)
            {
                bool left = true;
                panel1.Location = new Point(panel1.Location.X - delka, panel1.Location.Y);
            }
            if (e.KeyCode == Keys.Right && panel1.Location.X + panel1.Width < this.Width - delka *2)
            {
                bool right = true;
                panel1.Location = new Point(panel1.Location.X + delka, panel1.Location.Y);
            }
        }

        private void Form1_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Up)
            {
                bool up = false;
            }
            if (e.KeyCode == Keys.Down)
            {
                bool down = false;
            }
            if (e.KeyCode == Keys.Left)
            {
                bool left = false;
            }
            if (e.KeyCode == Keys.Right)
            {
                bool right = false;
            }

        }
    }
}